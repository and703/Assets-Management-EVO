Put contents of adminty-html.zip here.
