<?php
?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div>
</div>

<script src="<?php echo htmlspecialchars(BASE_URL); ?>assets/adminty/files/bower_components/jquery/js/jquery.min.js"></script>
<script src="<?php echo htmlspecialchars(BASE_URL); ?>assets/adminty/files/bower_components/popper.js/js/popper.min.js"></script>
<script src="<?php echo htmlspecialchars(BASE_URL); ?>assets/adminty/files/bower_components/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo htmlspecialchars(BASE_URL); ?>assets/adminty/files/assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="<?php echo htmlspecialchars(BASE_URL); ?>assets/adminty/files/assets/js/script.js"></script>

<script>
    function toggleFullScreen() {
        if ((document.fullScreenElement && document.fullScreenElement !== null) ||
            (!document.mozFullScreen && !document.webkitIsFullScreen)) {
            if (document.documentElement.requestFullScreen) {
                document.documentElement.requestFullScreen();
            } else if (document.documentElement.mozRequestFullScreen) {
                document.documentElement.mozRequestFullScreen();
            } else if (document.documentElement.webkitRequestFullScreen) {
                document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT);
            }
        } else {
            if (document.cancelFullScreen) {
                document.cancelFullScreen();
            } else if (document.mozCancelFullScreen) {
                document.mozCancelFullScreen();
            } else if (document.webkitCancelFullScreen) {
                document.webkitCancelFullScreen();
            }
        }
    }
</script>

</body>
</html>
