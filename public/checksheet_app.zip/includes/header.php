<?php
$user = current_user();
$currentPage = $_GET['page'] ?? 'checks_form';

function nav_active(string $page): string {
    global $currentPage;
    return $currentPage === $page ? ' active' : '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Check Sheet Inspection System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?php echo htmlspecialchars(BASE_URL); ?>assets/adminty/files/bower_components/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo htmlspecialchars(BASE_URL); ?>assets/adminty/files/assets/icon/themify-icons/themify-icons.css">
    <link rel="stylesheet" href="<?php echo htmlspecialchars(BASE_URL); ?>assets/adminty/files/assets/css/style.css">
    <link rel="stylesheet" href="<?php echo htmlspecialchars(BASE_URL); ?>assets/adminty/files/assets/css/jquery.mCustomScrollbar.css">
</head>
<body class="fix-menu">

<div id="pcoded" class="pcoded">
    <div class="pcoded-overlay-box"></div>
    <div class="pcoded-container navbar-wrapper">

        <nav class="navbar header-navbar pcoded-header">
            <div class="navbar-wrapper">

                <div class="navbar-logo">
                    <a href="<?php echo htmlspecialchars(BASE_URL . 'index.php'); ?>">
                        <span class="f-w-600">Check Sheet</span>
                    </a>
                </div>

                <div class="navbar-container container-fluid">
                    <ul class="nav-left">
                        <li>
                            <a href="#!" onclick="javascript:toggleFullScreen()">
                                <i class="ti-fullscreen"></i>
                            </a>
                        </li>
                    </ul>
                    <ul class="nav-right">
                        <?php if ($user): ?>
                            <li class="user-profile header-notification">
                                <a href="#!">
                                    <span><?php echo htmlspecialchars($user['username']); ?> (<?php echo htmlspecialchars($user['role']); ?>)</span>
                                    <i class="ti-angle-down"></i>
                                </a>
                                <ul class="show-notification profile-notification">
                                    <li>
                                        <a href="<?php echo htmlspecialchars(BASE_URL . 'index.php?page=checks_form'); ?>">
                                            <i class="ti-clipboard"></i> Check Entry
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo htmlspecialchars(BASE_URL . 'index.php?page=logout'); ?>">
                                            <i class="ti-layout-sidebar-left"></i> Logout
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>

            </div>
        </nav>

        <div class="pcoded-main-container">
            <div class="pcoded-wrapper">

                <nav class="pcoded-navbar">
                    <div class="pcoded-inner-navbar main-menu">

                        <ul class="pcoded-item pcoded-left-item">
                            <li class="<?php echo nav_active('checks_list'); ?>">
                                <a href="<?php echo htmlspecialchars(BASE_URL . 'index.php?page=checks_list'); ?>">
                                    <span class="pcoded-micon"><i class="ti-dashboard"></i></span>
                                    <span class="pcoded-mtext">Dashboard / Results</span>
                                </a>
                            </li>

                            <li class="<?php echo nav_active('checks_form'); ?>">
                                <a href="<?php echo htmlspecialchars(BASE_URL . 'index.php?page=checks_form'); ?>">
                                    <span class="pcoded-micon"><i class="ti-clipboard"></i></span>
                                    <span class="pcoded-mtext">Check Entry</span>
                                </a>
                            </li>

                            <li class="<?php echo nav_active('checks_list'); ?>">
                                <a href="<?php echo htmlspecialchars(BASE_URL . 'index.php?page=checks_list'); ?>">
                                    <span class="pcoded-micon"><i class="ti-list"></i></span>
                                    <span class="pcoded-mtext">Results</span>
                                </a>
                            </li>

                            <?php if (is_admin()): ?>
                                <li class="pcoded-hasmenu <?php echo in_array($currentPage, ['areas','check_sheets','users']) ? ' active pcoded-trigger' : ''; ?>">
                                    <a href="javascript:void(0)">
                                        <span class="pcoded-micon"><i class="ti-settings"></i></span>
                                        <span class="pcoded-mtext">Master Data</span>
                                    </a>
                                    <ul class="pcoded-submenu">
                                        <li class="<?php echo nav_active('areas'); ?>">
                                            <a href="<?php echo htmlspecialchars(BASE_URL . 'index.php?page=areas'); ?>">Areas</a>
                                        </li>
                                        <li class="<?php echo nav_active('check_sheets'); ?>">
                                            <a href="<?php echo htmlspecialchars(BASE_URL . 'index.php?page=check_sheets'); ?>">Check Sheets & Items</a>
                                        </li>
                                        <li class="<?php echo nav_active('users'); ?>">
                                            <a href="<?php echo htmlspecialchars(BASE_URL . 'index.php?page=users'); ?>">Users</a>
                                        </li>
                                    </ul>
                                </li>
                            <?php endif; ?>
                        </ul>

                    </div>
                </nav>

                <div class="pcoded-content">
                    <div class="page-header">
                        <div class="page-block">
                            <div class="row align-items-center">
                                <div class="col-md-8">
                                    <div class="page-header-title">
                                        <h5 class="m-b-10">Check Sheet Inspection System</h5>
                                        <p class="m-b-0 text-muted">Device & area inspection workflow</p>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <ul class="breadcrumb">
                                        <li class="breadcrumb-item">
                                            <a href="<?php echo htmlspecialchars(BASE_URL . 'index.php?page=checks_list'); ?>"><i class="ti-home"></i></a>
                                        </li>
                                        <li class="breadcrumb-item">
                                            <?php echo htmlspecialchars(ucwords(str_replace('_', ' ', $currentPage))); ?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="pcoded-inner-content">
                        <div class="main-body">
                            <div class="page-wrapper">
                                <div class="page-body">
